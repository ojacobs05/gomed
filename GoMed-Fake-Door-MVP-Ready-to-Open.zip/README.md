# GoMed Fake Door MVP

A lightweight, mobile-first landing page for validating interest in medication delivery to university residences. It uses plain HTML, Tailwind CSS (CDN), and vanilla JavaScript—no server or framework required.

## Files

- `index.html` — landing page and pilot-interest form
- `confirmation.html` — confirmation experience after form success
- `style.css` — custom visual, motion, and form styles
- `script.js` — analytics hooks, form validation, submission, and interactions

## Run locally

Open `index.html` in a browser. With default placeholders, the form follows a safe local-preview path: it does not transmit data and redirects to the confirmation page after a short loading state.

## Connect Google Analytics 4

Open `script.js` and replace `GA_MEASUREMENT_ID` with your GA4 Measurement ID (for example, `G-XXXXXXXXXX`). Events include Order Now clicks, scroll depth at 25/50/75/100%, form started, form completed, and confirmation viewed. Page views are captured by GA4 configuration.

## Connect Google Sheets via Apps Script

1. Create a Google Sheet with headers: Timestamp, Full Name, University, Residence, Phone Number, Email, Medication, Address, Preferred Pharmacy, Payment Method, Checkbox Accepted, Browser, Submission Time.
2. In **Extensions → Apps Script**, add a `doPost(e)` function that parses `e.postData.contents`, appends the values to the sheet, and returns text.
3. Deploy it as a Web App with access appropriate for your pilot.
4. Copy the Web App URL and replace `YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL` in `script.js`.

The page submits JSON with `fetch()` using `no-cors`, which avoids browser CORS errors for a standard Apps Script Web App. Test before collecting submissions.

## Deploy on Vercel

Upload this folder or import it from a repository. Choose the **Other** framework preset and deploy—no build command is needed. Before publishing, replace both placeholders and add a privacy notice appropriate for collecting personal and medication-related information.
